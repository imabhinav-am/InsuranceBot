# InsuranceBot
ChatBot Project using rasa

python -m rasa_core_sdk.endpoint --actions actions

python -m rasa_core.train interactive -s stories.md --nlu models/nlu/default/insbot -d domain.yml -o models/dialogue --verbose --endpoints endpoints.yml

python bot.py -d ./models/dialogue -u ./models/nlu/default/insbot -p 5005 --cors "*" --endpoints endpoints.yml --enable_api    

https://github.com/scalableminds/chatroom

## intent:choice
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"mn1"}](ch:mn1)
- /choice[{"ch":"mnpolicyfreq"}](ch:mnpolicyfreq)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"mn1"}](ch:mn1)
- /choice[{"ch":"mnpolicyfreq"}](ch:mnpolicyfreq)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"mn1"}](ch:mn1)
- /choice[{"ch":"mnpolicyfreq"}](ch:mnpolicyfreq)
- /choice[{"ch":"qly"}](ch:qly)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"faq3"}](ch:faq3)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"mn1"}](ch:mn1)
- /choice[{"ch":"mnpolicyfreq"}](ch:mnpolicyfreq)
- /choice[{"ch":"qly"}](ch:qly)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"mn1"}](ch:mn1)
- /choice[{"ch":"mnpolicyfreq"}](ch:mnpolicyfreq)
- /choice[{"ch":"yly"}](ch:yly)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)
- /choice[{"ch":"ch1"}](ch:ch1)

## intent:deny
- no
- no

## intent:dev
- /dev[{"ch":"mn2"}](ch:mn2)
- /dev[{"ch":"mn3"}](ch:mn3)
- /dev[{"ch":"mnpolicypay"}](ch:mnpolicypay)
- /dev[{"ch":"mn2"}](ch:mn2)

## intent:faq
- /faq[{"ch":"ch2"}](ch:ch2)
- /faq[{"ch":"ch2"}](ch:ch2)
- /faq[{"ch":"ch2"}](ch:ch2)
- /faq[{"ch":"ch2"}](ch:ch2)

## intent:greet
- hi
- hi
- hi
- hello
- hey
- hi
- hey
- hi
- hi
- hi
- hello
- hi
- hello
- hi
- hello
- hi
- hey
- hey
- hey
- hi
- hi
- hello
- hi
- hi

## intent:number
- [+918588010953](mobile:+ 918588010953)
- [+918588010953](mobile:+ 918588010953)
- [+918588010953](mobile:+ 918588010953)
- [+918588010953](mobile:+ 918588010953)
- [+919876543210](mobile:+ 919876543210)
- [+919876543210](mobile:+ 919876543210)
- [+918976543210](mobile:+ 918976543210)
- [+919867543210](mobile:+ 919867543210)
- [+919786543210](mobile:+ 919786543210)
- [+917689865431](mobile:+ 917689865431)
- [+919876543210](mobile:+ 919876543210)
- [+919876543210](mobile:+ 919876543210)
- [+918588010953](mobile:+ 918588010953)
- [+918765432109](mobile:+ 918765432109)

## intent:otpi
- [123472](otp)
- [180808](otp)
- [855583](otp)
- [092775](otp)
- [845805](otp)
- [123456](otp)
- [743381](otp)
- [105727](otp)
- [781213](otp)
- [497282](otp)
- [791950](otp)
- [123456](otp)
- [123456](otp)
- [123456](otp)
- [123456](otp)
- [123456](otp)
- [123456](otp)
- [123456](otp)

## intent:policynumber
- /policynumber[{"policy": "21334645"}](policy:21334645)
- /policynumber[{"policy": "12345678"}](policy:12345678)
- /policynumber[{"policy": "12345678"}](policy:12345678)
- /policynumber[{"policy": "12345678"}](policy:12345678)
- /policynumber[{"policy": "12345678"}](policy:12345678)
- /policynumber[{"policy": "21334645"}](policy:21334645)
- /policynumber[{"policy": "12345678"}](policy:12345678)
- /policynumber[{"policy": "12345678"}](policy:12345678)
- /policynumber[{"policy": "12345678"}](policy:12345678)

## synonym:+ 917689865431
- +917689865431

## synonym:+ 918588010953
- +918588010953

## synonym:+ 918976543210
- +918976543210

## synonym:+ 919786543210
- +919786543210

## synonym:+ 919867543210
- +919867543210

## synonym:+ 919876543210
- +919876543210

## synonym:12345678
- {"policy": "12345678"}

## synonym:21334645
- {"policy": "21334645"}

## synonym:ch1
- {"ch":"ch1"}

## synonym:ch2
- {"ch":"ch2"}

## synonym:faq3
- {"ch":"faq3"}

## synonym:mn1
- {"ch":"mn1"}

## synonym:mn2
- {"ch":"mn2"}

## synonym:mn3
- {"ch":"mn3"}

## synonym:mnpolicyfreq
- {"ch":"mnpolicyfreq"}

## synonym:mnpolicypay
- {"ch":"mnpolicypay"}

## synonym:qly
- {"ch":"qly"}

## synonym:yly
- {"ch":"yly"}

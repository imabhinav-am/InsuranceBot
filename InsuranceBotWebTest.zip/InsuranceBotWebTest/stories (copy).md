## fallback
- utter_unclear
- utter_start

## Generated Story 7170865673298004631
* greet
    - utter_greet
    - utter_start
* choice{"ch": "ch1"}
    - slot{"ch": "ch1"}
    - action_welcm_done
* number{"mobile": "7980453647"}
    - slot{"mobile": "7980453647"}
    - get_number_form
    - form{"name": "get_number_form"}
    - slot{"mobile": "7980453647"}
    - slot{"mobile": "7980453647"}
    - form{"name": null}
    - slot{"requested_slot": null}
* otpi{"otp": "111111"}
    - slot{"otp": "111111"}
    - verify_otp
    - slot{"verifyotp": "false"}
> chkans

## user wants to continue
> chkans
* affirm
    - utter_restart
    - action_restart

## user does not want to continue
> chkans
* deny
    - utter_goodbye
    - action_restart

## normal flow
> chkans
* policynumber{"policy": "12345678"}
    - slot{"policy": "12345678"}
    - action_show_details
* goodbye
    - utter_goodbye
    - action_restart

## Generated Story 2795370918594262598
* greet
    - utter_greet
    - utter_start
* choice{"ch": "ch1"}
    - slot{"ch": "ch1"}
    - action_welcm_done
* number{"mobile": "7894561232"}
    - slot{"mobile": "7894561232"}
    - get_number_form
    - form{"name": "get_number_form"}
    - slot{"mobile": "7894561232"}
    - slot{"mobile": "7894561232"}
    - form{"name": null}
    - slot{"requested_slot": null}
* otpi{"otp": "236548"}
    - slot{"otp": "236548"}
    - verify_otp
    - slot{"verifyotp": "false"}
* deny
    - utter_goodbye
    - action_restart

## Generated Story -8011478683541276106
* greet
    - utter_greet
    - utter_start
* choice{"ch": "ch1"}
    - slot{"ch": "ch1"}
    - action_welcm_done
* otpi{"otp": "254789"}
    - slot{"otp": "254789"}
    - verify_otp
    - slot{"verifyotp": "false"}
* affirm
    - action_restart

## Generated Story -3527959859852346662
* greet
    - utter_greet
    - utter_start
* choice{"ch": "ch1"}
    - slot{"ch": "ch1"}
    - action_welcm_done
* number{"mobile": "8954685956"}
    - slot{"mobile": "8954685956"}
    - get_number_form
    - form{"name": "get_number_form"}
    - slot{"mobile": "8954685956"}
    - slot{"mobile": "8954685956"}
    - form{"name": null}
    - slot{"requested_slot": null}
* otpi{"otp": "632245"}
    - slot{"otp": "632245"}
    - verify_otp
    - slot{"verifyotp": "true"}
* policynumber{"policy": "12345678"}
    - slot{"policy": "12345678"}
    - action_show_details
* goodbye
    - utter_goodbye
    - action_restart


## Generated Story 841950212237719972
* greet
    - utter_greet
    - utter_start
* choice{"ch": "ch1"}
    - slot{"ch": "ch1"}
    - action_welcm_done
* number{"mobile": "+ 917894563215"}
    - slot{"mobile": "+ 917894563215"}
    - get_number_form
    - form{"name": "get_number_form"}
    - slot{"mobile": "+ 917894563215"}
    - slot{"mobile": "+ 917894563215"}
    - slot{"mobile": "7894563215"}
    - form{"name": null}
    - slot{"requested_slot": null}
* otpi{"otp": "164638"}
    - slot{"otp": "164638"}
    - verify_otp
    - slot{"verifyotp": "true"}
* goodbye
    - action_restart

## Generated Story -6225030395302291769
* greet
    - utter_greet
    - utter_start
* choice{"ch": "ch1"}
    - slot{"ch": "ch1"}
    - action_welcm_done
* number{"mobile": "+ 918588010953"}
    - slot{"mobile": "+ 918588010953"}
    - get_number_form
    - form{"name": "get_number_form"}
    - slot{"mobile": "+ 918588010953"}
    - slot{"mobile": "+ 918588010953"}
    - slot{"mobile": "8588010953"}
    - form{"name": null}
    - slot{"requested_slot": null}
* otpi{"otp": "637800"}
    - slot{"otp": "637800"}
    - verify_otp
    - slot{"verifyotp": "true"}
* policynumber{"policy": "12345678"}
    - slot{"policy": "12345678"}
    - action_show_details
* choice{"ch": "mn1"}
    - slot{"ch": "mn1"}
    - action_manage_policy
* choice{"ch": "mnpolicyfreq"}
    - slot{"ch": "mnpolicyfreq"}
    - utter_continue
* affirm
    - action_manage_policy
* deny
    - utter_goodbye
    - action_restart

## Generated Story -6868406487360377059
* greet
    - utter_greet
    - utter_start
* choice{"ch": "ch1"}
    - slot{"ch": "ch1"}
    - action_welcm_done
* number{"mobile": "+ 918588010953"}
    - slot{"mobile": "+ 918588010953"}
    - get_number_form
    - form{"name": "get_number_form"}
    - slot{"mobile": "+ 918588010953"}
    - slot{"mobile": "+ 918588010953"}
    - slot{"mobile": "8588010953"}
    - form{"name": null}
    - slot{"requested_slot": null}
* otpi{"otp": "650643"}
    - slot{"otp": "650643"}
    - verify_otp
    - slot{"verifyotp": "true"}
* policynumber{"policy": "12345678"}
    - slot{"policy": "12345678"}
    - action_show_details
* choice{"ch": "mn1"}
    - slot{"ch": "mn1"}
    - action_manage_policy
* choice{"ch": "mnpolicyfreq"}
    - slot{"ch": "mnpolicyfreq"}
    - utter_continue
* affirm
    - action_manage_policy
* choice{"ch": "mnpolicyfreq"}
    - slot{"ch": "mnpolicyfreq"}
    - utter_continue
* deny
    - utter_goodbye
    - action_restart

## Generated Story 5967263668578254010
* greet
    - utter_greet
    - utter_start
* choice{"ch": "ch1"}
    - slot{"ch": "ch1"}
    - action_welcm_done
* number{"mobile": "+ 918588010953"}
    - slot{"mobile": "+ 918588010953"}
    - get_number_form
    - form{"name": "get_number_form"}
    - slot{"mobile": "+ 918588010953"}
    - slot{"mobile": "+ 918588010953"}
    - slot{"mobile": "8588010953"}
    - form{"name": null}
    - slot{"requested_slot": null}
* otpi{"otp": "123472"}
    - slot{"otp": "123472"}
    - verify_otp
    - slot{"verifyotp": "true"}
* policynumber{"policy": "21334645"}
    - slot{"policy": "21334645"}
    - action_show_details
* choice{"ch": "mn1"}
    - slot{"ch": "mn1"}
    - action_manage_policy
* choice{"ch": "mnpolicyfreq"}
    - slot{"ch": "mnpolicyfreq"}
    - utter_continue
* deny
    - action_restart


## Generated Story -4998870153613528480
* greet
    - utter_greet
    - utter_start
* choice{"ch": "ch1"}
    - slot{"ch": "ch1"}
    - action_welcm_done

## Generated Story -2180144193998184829
* greet
    - utter_greet
    - utter_start
* choice{"ch": "ch1"}
    - slot{"ch": "ch1"}
    - action_welcm_done
* number{"mobile": "+ 918588010953"}
    - slot{"mobile": "+ 918588010953"}
    - get_number_form
    - form{"name": "get_number_form"}
    - slot{"mobile": "+ 918588010953"}
    - slot{"mobile": "+ 918588010953"}
    - slot{"mobile": "8588010953"}
    - form{"name": null}
    - slot{"requested_slot": null}
* otpi{"otp": "180808"}
    - slot{"otp": "180808"}
    - verify_otp
    - slot{"verifyotp": "true"}
* policynumber{"policy": "12345678"}
    - slot{"policy": "12345678"}
    - action_show_details
* choice{"ch": "mn1"}
    - slot{"ch": "mn1"}
    - action_manage_policy
* choice{"ch": "mnpolicyfreq"}
    - slot{"ch": "mnpolicyfreq"}
    - utter_continue
* deny
    - action_restart


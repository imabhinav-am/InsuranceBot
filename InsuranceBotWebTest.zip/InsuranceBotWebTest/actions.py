# -*- coding: utf-8 -*-
from typing import Dict, Text, Any, List, Union

from rasa_core_sdk import Action
from rasa_core_sdk import ActionExecutionRejection
from rasa_core_sdk import Tracker
from rasa_core_sdk.events import SlotSet, UserUttered, Restarted, FollowupAction
from rasa_core_sdk.executor import CollectingDispatcher
from rasa_core_sdk.forms import FormAction
import requests
import json
import pyotp
import time
import sqlite3
import sys

print("Hello")
chk = 0
ctr = 1

def genotp():
    totp = pyotp.TOTP('base32secret3232')
    x = totp.now()
    return x

class GetNumber(FormAction):

    def name(self):
        return "get_number_form"

    @staticmethod
    def required_slots(tracker: Tracker) -> List[Text]:
        return ["mobile"]

    def slot_mappings(self):
        return {"mobile": self.from_entity(entity="mobile",
                                            intent="number")}

    def validate(self,
                 dispatcher: CollectingDispatcher,
                 tracker: Tracker,
                 domain: Dict[Text, Any]) -> List[Dict]:
        
        slot_values = self.extract_other_slots(dispatcher, tracker, domain)

        for slot, value in slot_values.items():
            if slot == 'mobile':
                if len(str(value)) != 14:
                    dispatcher.utter_message('Please enter correct mobile number!!!')
                    slot_values[slot] = None

        return [SlotSet(slot, value) for slot, value in slot_values.items()]

    def submit(self,
               dispatcher: CollectingDispatcher,
               tracker: Tracker,
               domain: Dict[Text, Any]) -> List[Dict]:
        no =  str(tracker.slots["mobile"])
        no = no.replace("+ 91", "")
        print(no)
        x = genotp()
        print(x)
        global chk
        chk = x
        # url = "https://www.fast2sms.com/dev/bulk"
        # querystring = {"authorization":"ZveYGtugc6MiHhCqLoI27zksmAlWVrPySwdN94TBx5QURa3E8j8lX9LSirfCDhVF451xdRZb6ywWMU2Y","sender_id":"FSTSMS","language":"english","route":"qt","message":"10538","variables":"{BB}"}
        # headers = {'cache-control': "no-cache"}
        # querystring["numbers"] = "{}".format(no)
        # querystring["variables_values"] = "{}".format(x)
        # response = requests.request("GET", url, headers=headers, params=querystring)
        # print(response.text)
        # url = "https://www.fast2sms.com/dev/bulk"
        # querystring = {"authorization":"ZveYGtugc6MiHhCqLoI27zksmAlWVrPySwdN94TBx5QURa3E8j8lX9LSirfCDhVF451xdRZb6ywWMU2Y","sender_id":"FSTSMS","language":"english","route":"p"}
        # querystring["message"] = "OTP for Verification : {}".format(x)
        # #print(querystring["message"])
        
        # headers = {'cache-control': "no-cache"}
        # response = requests.request("GET", url, headers=headers, params=querystring)
        # print(response.text)
        dispatcher.utter_template('utter_otp_sent', tracker)
        return [SlotSet("mobile",no)]

class otpverify(FormAction):
    def name(self):
        return "action_verify_otp"

    @staticmethod
    def required_slots(tracker: Tracker) -> List[Text]:
        return ["otp"]

    def slot_mappings(self):
        return {"otp": self.from_entity(entity="otp",
                                            intent="otpi")}

    def validate(self,
                 dispatcher: CollectingDispatcher,
                 tracker: Tracker,
                 domain: Dict[Text, Any]) -> List[Dict]:
        otp = tracker.slots['otp']
        print(otp)
        #print("123")
        global chk
        print(chk)
        global ctr
        if otp == chk:
            #dispatcher.utter_template('utter_correct', tracker)
            #mb = tracker.slots['mobile']
            ab = ""
            mb = int("9876543210")
            conn = sqlite3.connect('clients')
            cursor = conn.execute("SELECT * from policydetails where MobileNumber={}".format(mb))
            buttons = []
            nm = ""
            for row in cursor:
                #print("Policy Number : {}".format(row[0]))
                dd = {}
                nm = row[2]
                dd["title"] = str(row[0])
                temp = {}
                temp["policy"] = str(row[0])
                st = '/policynumber' + json.dumps(temp)
                dd["payload"] = st
                buttons.append(dd)
                #print(buttons)
            if nm!="":
                msg = "Welcome {} ! You have the following policies registered with us, Please select one to manage: ".format(nm)
                dispatcher.utter_button_message(msg,buttons)
            else:
                dispatcher.utter_message("No policy found for the provided number")
                dispatcher.utter_template("utter_goodbye", tracker)
            conn.close()
            return [SlotSet("verifyotp","true")]
        else:
            ctr = tracker.slots['attempts']
            if ctr == 3.0:
                dispatcher.utter_message("Maximum number of tries done...Thank you for using our services")
                return[FollowupAction("action_restart"),SlotSet("otp",None),SlotSet("attempts",1.0)]
            else:
                dispatcher.utter_message("Incorrect OTP ({} attempts left), Please try again!!! ".format(int(3.0-ctr)))
                ctr += 1.0
                print(ctr)
                return [SlotSet("otp",None), SlotSet("attempts",ctr)]
        return []
        

    def submit(self,
               dispatcher: CollectingDispatcher,
               tracker: Tracker,
               domain: Dict[Text, Any]) -> List[Dict]:
        
        return []

class welcomeDone(Action):
    def name(self):
        return "action_welcm_done"

    def run(self, dispatcher, tracker, domain):
        if tracker.slots['ch']=='ch1':
            dispatcher.utter_template("utter_ask_no", tracker)
        else:
            dispatcher.utter_template("utter_faq", tracker)
        return []

class showPolicyDetails(Action):
    def name(self):
        return "action_show_details"

    def run(self, dispatcher, tracker, domain):
        pl = tracker.slots['policy']
        conn = sqlite3.connect('clients')
        cursor = conn.execute("SELECT * from policydetails where PolicyNumber={}".format(pl))
        for row in cursor:
            dispatcher.utter_message("Policy Number      : {}".format(row[0]))
            dispatcher.utter_message("Mobile Number      : {}".format(row[1]))
            dispatcher.utter_message("Policy Holder Name : {}".format(row[2]))
            dispatcher.utter_message("Policy Status      : {}".format(row[3]))
            dispatcher.utter_message("Due From           : {}".format(row[4]))
            dispatcher.utter_message("Policy Fequency    : {}".format(row[5]))
        dispatcher.utter_template("utter_manage", tracker)
        return []

class manageDetails(Action):
	def name(self):
		return "action_manage_policy"

	def run(self, dispatcher, tracker, domain):
		duetime = "15"
		dd = {}
		buttons = []
		dd["title"] = "Pay Premium"
		dd["payload"] = '/choice{"ch":"mnpolicypay"}'
		buttons.append(dd)
		dd = {}
		dd["title"] = "Change Frequency"
		dd["payload"] = '/choice{"ch":"mnpolicyfreq"}'
		buttons.append(dd)
		msg = "I see your policy is due in  {} days, what would you like me to do : ".format(duetime)
		dispatcher.utter_button_message(msg, buttons)
		return []

class updFreq(Action):
    def name(self):
        return "action_updated_freq"

    def run(self, dispatcher, tracker, domain):
        st = tracker.slots['ch']
        if st == "mly":
            st = "Monthly"
        elif st == "qly":
            st = "Quarterly"
        else:
            st = "Yearly"
        dispatcher.utter_message("Policy frequency successfully updated to {} mode".format(st))
        return []


class updFreq(Action):
    def name(self):
        return "action_faq"

    def run(self, dispatcher, tracker, domain):
        st = tracker.slots['ch']
        if st == "faq1":
            dispatcher.utter_message("For any assistance or query relating to claims, please get in touch with us at:") 
            dispatcher.utter_message("Dedicated claims helpdesk: 0124-4444444 Operational Hours: 9:00 AM to 6:00 PM (Monday - Friday)") 
            dispatcher.utter_message("Toll Free Number: 1800-100-1000 Operational Hours: 9:30 AM to 6:30 PM (Monday - Saturday)") 
            dispatcher.utter_message("Mail us at claims@lifeinsurance.com")
        elif st == "faq2":
            dispatcher.utter_message("The nominee or appointee (in case of minor nominee) last recorded under the policy in case of a policy on own life")
            dispatcher.utter_message("The proposer in case the policy is not on own life") 
            dispatcher.utter_message("Assignee in case the policy was assigned")
        else:
            dispatcher.utter_message("We provide four convenient ways of intimation:")
            dispatcher.utter_message("Walk into any of our Life Insurance branches")
            dispatcher.utter_message("Notify us online at www.lifeinsurance.com")
            dispatcher.utter_message("Notify us on whatsapp no XXXXXXXX")
            dispatcher.utter_message("Write to us at claims@dhflpramerica.com")
            dispatcher.utter_message("You also call us at 1800-100-1000")
        return []
from rasa_nlu.training_data import load_data
from rasa_nlu.config import RasaNLUModelConfig
from rasa_nlu.model import Trainer
from rasa_nlu import config

from rasa_core.policies import FallbackPolicy, KerasPolicy, MemoizationPolicy
from rasa_core.agent import Agent

# loading the nlu training samples
training_data = load_data("nlu.md")

# trainer to educate our pipeline
trainer = Trainer(config.load("config.yml"))

# training the model
interpreter = trainer.train(training_data)
model_directory = trainer.persist("./models/nlu", fixed_model_name="insbot")

# # this will catch predictions the model isn't very certain about
# # there is a threshold for the NLU predictions as well as the action predictions
# fallback = FallbackPolicy(fallback_action_name="utter_unclear",
#                           core_threshold=0.2,
#                           nlu_threshold=0.1)

# agent = Agent('domain.yml', policies=[MemoizationPolicy(), KerasPolicy(), fallback])

# # loading our neatly defined training dialogues
# training_data = agent.load_data('stories.md')

# agent.train(training_data)

# agent.persist('models/dialogue')